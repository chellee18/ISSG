const io = require("socket.io-client");

const socket = io("http://localhost:3000"); // Menghubungkan ke server socket.io yang berjalan di localhost:3000

const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let username = ""; // Variabel untuk menyimpan nama pengguna

// Saat terhubung ke server
socket.on("connect", () => {
  console.log("Connected to the server");
  
  // Meminta pengguna untuk memasukkan nama pengguna
  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username} to the chat`);
    rl.prompt();

    // Menangani input pesan pengguna
    rl.on("line", (message) => {
      if (message.trim()) {
        // Mengirimkan pesan ke server
        socket.emit("message", { username, message });
      }
      rl.prompt();
    });
  });
});

// Menerima pesan dari server dan menampilkan pesan dari pengguna lain
socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage } = data;
  if (senderUsername !== username) {
    console.log(`${senderUsername}: ${senderMessage}`);
  }
  rl.prompt();
});

// Menangani pemutusan koneksi dengan server
socket.on("disconnect", () => {
  console.log("Disconnected from server");
  rl.close();
  process.exit(0);
});

// Menangani keluar dari aplikasi dengan SIGINT (Ctrl+C)
rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});
