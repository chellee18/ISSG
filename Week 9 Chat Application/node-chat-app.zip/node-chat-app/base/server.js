const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer(); // Membuat server HTTP
const io = socketIo(server); // Menginisialisasi socket.io dengan server HTTP

// Menangani koneksi dari client
io.on("connection", (socket) => {
  console.log(`Client ${socket.id} connected`); // Menampilkan ID client yang terhubung

  // Menangani pesan yang dikirim oleh client
  socket.on("message", (data) => {
    const { username, message } = data;
    // Mengirimkan pesan ke semua client yang terhubung
    io.emit("message", { username, message });
  });

  // Menangani saat client terputus
  socket.on("disconnect", () => {
    console.log(`Client ${socket.id} disconnected`); // Menampilkan ID client yang terputus
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`); // Menampilkan pesan bahwa server berjalan pada port tertentu
});
